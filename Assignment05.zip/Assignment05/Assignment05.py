#-------------------------------------------------#
# Title:    Assignment05
# Dev:      Nick Prak
# Date:     October 31, 2016
# Desc:     Working with dictionaries
# ChangeLog:
#-------------------------------------------------#


#-- Data --#
# declare variables and constants
# dictionary: A dictionary of tasks (key) and priorities (values)
# list: Dictionary elements stored in a list
# line: A row of text data from the file
# objFile: An object that represents a file
# choice: User input choice from options
# data: Data elements from each row of information
# key: Tasks in the dictionary
# value: Priorities in the dictionary
# task: Keys in the dictionary
# priority: Values in the dictionary
# removeKey: Key to be removed from dictionary

#-- Processing --#
# Create text file called Todo.txt with provided data
# Load data from text file into Python dictionary object
# Add dictionary rows into a Python list
# Display contents of the list to user
# Allow options for the user to Add/Remove tasks from the list with numbered choices
# Save the data from teh table into the Todo.txt file when the program exits


#-- Presentation (Input/Output) --#
# Prompt for user input of options to perform
# Print program output to use and file

# Function to display the dictionary in a visual format
def displayDictionary():
    print("\n")
    for key, value in dictionary.items():
        print("Task: " + key + " | Priority: " + value)
    print("\n")

print("Assignment 05 \n")

# Create text file called Todo.txt with provided data
#objFile = open("Todo.txt", "w")
#objFile.write("Clean House,low")
#objFile.write("Pay Bills,high")
#objFile.close()

# Load data from text file into Python dictionary object
dictionary = {}
list = []
objFile = open("Todo.txt", "r+") # r+ opens the file for reading and writing
for line in objFile:
    data = line.split(",")
    key = data[0].strip() # task
    value = data[1].strip() # priority
    dictionary[key] = value
    list = dictionary.items() # # Add dictionary rows into a Python list
objFile.close()

# Display contents of the list to user
for key, value in list:
    print("Task: " + key + " | Priority: " + value)
print("\n")

# Allow options for the user to Add/Remove tasks from the list with numbered choices
while(True):
    print("Select Option:")
    print("1) Add task")
    print("2) Remove task")
    print("3) Display tasks and priorities")
    print("4) Save all tasks to the Todo.txt file and exit!")
    choice = str(input("Which option would you like to choose?: ")) # string for conditional statements
    if (choice == '1'): # Add task
        task = raw_input("\nEnter the task: ")
        priority = raw_input("Enter the priority: ")
        print("\n")
        dictionary[task] = priority
    elif (choice == '2'): # Remove task
        displayDictionary()
        removeKey = raw_input("Which task would you like to remove?: ")
        if (removeKey in dictionary):
            del dictionary[removeKey]
        else:
            print("Invalid input: Task not available")
    elif (choice == '3'): # Display tasks and priorities
        displayDictionary()
    elif (choice == '4'): # Save and exit
        objFile = open("Todo.txt", "w") # write to file
        for key, value in dictionary.items():
            objFile.write(key + "," + value + "\n")
        objFile.close()
        break
    else:
        print("Invalid input")
print("\nEnd of Program")